//
//  MapVC.swift
//  PogodaOrlov
//
//  Created by user on 01.03.2021.
//

import UIKit
import MapKit
import CoreLocation

class MapVC: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate{

    @IBOutlet weak var mapView: MKMapView!
    let location = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        location.delegate = self
        mapView.delegate = self
        location.startUpdatingLocation()
        mapView.showsUserLocation = true
        mapView.userLocation.title = "im here"
        mapView.userLocation.subtitle = "you found me"

        // Do any additional setup after loading the view.
    }
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotation? {
        if annotation.coordinate.latitude != mapView.userLocation.coordinate.latitude && annotation.coordinate.longitude != mapView.userLocation.coordinate.longitude{
            
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
