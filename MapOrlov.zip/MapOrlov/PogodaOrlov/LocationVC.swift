//
//  ViewController.swift
//  PogodaOrlov
//
//  Created by user on 01.03.2021.
//

import UIKit
import CoreLocation




class LocationVC: UIViewController, CLLocationManagerDelegate {
    let locationmanager = CLLocationManager()

    @IBOutlet weak var datalat: UILabel!
    @IBOutlet weak var datalon: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        checkAuthorization()
        // Do any additional setup after loading the view.
    }
    func checkAuthorization(){
        switch CLLocationManager.authorizationStatus() {
        case .authorizedWhenInUse:
            locationmanager.delegate = self
            locationmanager.desiredAccuracy = kCLLocationAccuracyBest
            locationmanager.startUpdatingLocation()
            print("error")
        case .notDetermined:
            locationmanager.requestWhenInUseAuthorization()
        default:
            break
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        if let location = locations.last?.coordinate{
            datalat.text = String(location.latitude)
            datalon.text = String(location.longitude)
            locationmanager.stopUpdatingLocation()
        }
    }

}

